﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using System.Windows;
using System.Xml;

using Str = CLauncher.Config.Strings;
using Clr = CLauncher.Config.Colors;

using Global = CLauncher.Config.Conf;
using System.Windows.Media;
using System.Windows.Media.Imaging;

namespace CLauncher
{
    /// <summary>
    /// App.xaml 的交互逻辑
    /// </summary>
    public partial class App : Application
    {
        public App()
        {
            BitmapImage image = new BitmapImage();
            image.BeginInit();
            image.UriSource = new Uri(AppDomain.CurrentDomain.BaseDirectory + @"Resource\background.png");
            image.EndInit();
            Global.MWBG = new ImageBrush()
            {
                Stretch = Stretch.Uniform,
                ImageSource = image
            };
            if (!File.Exists(AppDomain.CurrentDomain.BaseDirectory + @"Resource\CLaunchConf.xml")) Shutdown();
            if (!File.Exists(AppDomain.CurrentDomain.BaseDirectory + @"ra2ca.ini")) Shutdown();


            XmlDocument ConfigXML = new XmlDocument();// 实例化 XmlDocument 类
            try
            {
                ConfigXML.Load(AppDomain.CurrentDomain.BaseDirectory + @"Resource\CLaunchConf.xml");// 读入XML文档
            }
            catch (XmlException )// 异常处理
            {

                Shutdown();
            }
            XmlNode Root = ConfigXML.SelectSingleNode("CLaunchConfigs");// 获取 Root 节点
            XmlNode node;
            XmlElement xe;
            #region 字符串初始化
            {
                node = ConfigXML.SelectSingleNode("CLaunchConfigs/Strings");
                xe = (XmlElement)node;
                Str.Title = xe.GetAttribute("Title");
                Str.Launch = xe.GetAttribute("Launch");
                Str.Settings = xe.GetAttribute("Settings");
                Str.About = xe.GetAttribute("About");
                Str.Exit = xe.GetAttribute("Exit");
                Str.Mission = xe.GetAttribute("Mission");
                Str.Summary = xe.GetAttribute("Summary");
                Str.Easy = xe.GetAttribute("Easy");
                Str.Normal = xe.GetAttribute("Normal");
                Str.Hard = xe.GetAttribute("Hard");
                Str.Run = xe.GetAttribute("Run");
                Str.VideoSettings = xe.GetAttribute("VideoSettings");
                Str.Screen = xe.GetAttribute("Screen");
                Str.IsWindow = xe.GetAttribute("IsWindow");
                Str.NoFrame = xe.GetAttribute("NoFrame");
                Str.UseGraphicsAPI = xe.GetAttribute("UseGraphicsAPI");
                Str.GraphicsAPI = xe.GetAttribute("GraphicsAPI");
                Str.AudioSettings = xe.GetAttribute("AudioSettings");
                Str.BGM = xe.GetAttribute("BGM");
                Str.VOX = xe.GetAttribute("VOX");
                Str.SEM = xe.GetAttribute("SEM");
            }
            #endregion
            #region 颜色初始化
            {
                node = ConfigXML.SelectSingleNode("CLaunchConfigs/Colors");
                xe = (XmlElement)node;
                Clr.Foreground = Tools.String2Brush(xe.GetAttribute("Foreground"));
                Clr.ThemeColor = Tools.String2Brush(xe.GetAttribute("ThemeColor"));
            }
            #endregion
            #region 任务加载
            {
                node = ConfigXML.SelectSingleNode("CLaunchConfigs/Missions");
                //xe = (XmlElement)node;
                XmlNodeList nodeList = node.ChildNodes;
                foreach (XmlNode nd in nodeList)
                {
                    xe = (XmlElement)nd;
                    Global.Missions.Add(new MissionList(
                        xe.GetAttribute("Name"),
                        xe.GetAttribute("Summary"),
                        xe.GetAttribute("Spawn")
                        )
                    );
                }
            }
            #endregion

            #region RA2CA.INI Reader
            {
                string line;
                FileStream fs = new FileStream(AppDomain.CurrentDomain.BaseDirectory + @"ra2ca.ini", FileMode.Open);
                StreamReader sr = new StreamReader(fs);
                while (!sr.EndOfStream)
                {
                    // 过滤注释
                    line = sr.ReadLine().Split(';')[0];
                    // 如果是空行则跳过本次循环
                    if (line.Length == 0) continue;
                    // 键值对检测
                    else if (line.Contains("="))
                    {
                        string linea = line.Split('=')[0];
                        string lineb = line.Split('=')[1];
                        switch (linea)
                        {
                            case "Difficulty":
                                Global.Difficult = Convert.ToInt32(lineb);
                                break;
                            case "Video.Windowed":
                                if (lineb.Equals("0")) Global.IsWindow = false;
                                else Global.IsWindow = true;
                                break;
                            case "NoWindowFrame":
                                if (lineb.Equals("0")) Global.NoFrame = false;
                                else Global.NoFrame = true;
                                break;
                            case "SoundVolume":
                                Global.BGM = Convert.ToDouble(lineb);
                                break;
                            case "VoiceVolume":
                                Global.VOX = Convert.ToDouble(lineb);
                                break;
                            case "ScoreVolume":
                                Global.SEM = Convert.ToDouble(lineb);
                                break;
                            case "ScreenWidth":
                                Global.Width = Convert.ToInt32(lineb);
                                break;
                            case "ScreenHeight":
                                Global.Height = Convert.ToInt32(lineb);
                                break;
                            default:
                                break;
                        }
                    }
                }
                sr.Close();
                fs.Dispose();
            }
            #endregion
        }
    }
}
