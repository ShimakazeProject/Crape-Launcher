﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

using Str = CLauncher.Config.Strings;
using Clr = CLauncher.Config.Colors;
namespace CLauncher
{
    /// <summary>
    /// MainWindow.xaml 的交互逻辑
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
            tbTitle.Text = Str.Title;
            miLaunch.Header = Str.Launch;
            miSettings.Header = Str.Settings;
            miAbout.Header = Str.About;
            miExit.Header = Str.Exit;
            Foreground = Clr.Foreground;
            menu.Foreground = Clr.Foreground;
            ccUserArea.Content = new UC1();
            Background = Config.Conf.MWBG;
        }
        private void ExitButtonClick(object sender, RoutedEventArgs e) => Close();

        private void LaunchItem_Click(object sender, RoutedEventArgs e) => ccUserArea.Content = new UC1();

        private void SettingsItem_Click(object sender, RoutedEventArgs e) => ccUserArea.Content = new UC2();

        private void AboutItem_Click(object sender, RoutedEventArgs e) => ccUserArea.Content = new UC3();

    }
}
